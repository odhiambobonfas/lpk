# Run-to-Green Manual

## 1. Configure

```bash
cd api
cp .env.example .env
```

## 2. Install and migrate

```bash
npm install
npx prisma generate
npx prisma migrate dev --name feat_tveta_compliance_schema_closure
npm run seed
```

Copy the printed `STUDENT_ACCESS_TOKEN` and `liveSessionId`.

## 3. Launch

```bash
npm run start:dev
```

## 4. Verify API is alive

```bash
curl -i http://localhost:3000/api/auth/me
```

Expected: 401 JSON response, not ECONNREFUSED.

## 5. Verify auth

```bash
curl -i http://localhost:3000/api/auth/me -H "Authorization: Bearer STUDENT_ACCESS_TOKEN"
```

## 6. Verify live access

```bash
curl -i http://localhost:3000/api/live/access/validate \
  -H "Content-Type: application/json" \
  -d '{"accessToken":"STUDENT_ACCESS_TOKEN","liveSessionId":"LIVE_SESSION_ID"}'
```

## 7. Align mediasoup

```env
ICS_LIVE_API_BASE_URL=http://localhost:3000/api
ICS_LIVE_SERVICE_TOKEN=replace-with-shared-service-token
```

## 8. Align frontend

```env
REACT_APP_ICS_LIVE_API_BASE_URL=http://localhost:3000/api
```
