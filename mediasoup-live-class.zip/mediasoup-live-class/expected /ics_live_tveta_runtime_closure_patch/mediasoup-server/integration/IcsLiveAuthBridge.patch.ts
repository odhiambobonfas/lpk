export async function validateIcsLiveToken(accessToken: string) {
  const baseUrl = process.env.ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';
  const res = await fetch(`${baseUrl}/auth/me`, { headers: { Authorization: `Bearer ${accessToken}` } });
  if (!res.ok) throw new Error(`ICS_LIVE_AUTH_FAILED:${res.status}`);
  return res.json();
}

export async function validateLiveAccess(accessToken: string, liveSessionId: string) {
  const baseUrl = process.env.ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';
  const res = await fetch(`${baseUrl}/live/access/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.ICS_LIVE_SERVICE_TOKEN || ''}` },
    body: JSON.stringify({ accessToken, liveSessionId }),
  });
  if (!res.ok) throw new Error(`ICS_LIVE_ACCESS_DENIED:${res.status}`);
  return res.json();
}
