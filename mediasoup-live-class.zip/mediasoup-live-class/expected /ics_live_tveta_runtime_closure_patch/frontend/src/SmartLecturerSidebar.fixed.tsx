import React, { useState } from 'react';

type Props = { accessToken: string; studentId?: string; courseId?: string; liveSessionId?: string };
const API_BASE_URL = process.env.REACT_APP_ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';

export function SmartLecturerSidebar({ accessToken, studentId, courseId, liveSessionId }: Props) {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  async function askSmartLecturer() {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/ai-tutor/ask`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ question, studentId, courseId, liveSessionId }),
      });
      if (!res.ok) throw new Error(`Smart Lecturer failed: ${res.status}`);
      const data = await res.json();
      setAnswer(data.answer);
    } catch (err: any) {
      setAnswer(err.message || 'Smart Lecturer connection failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <aside className="smart-lecturer-sidebar">
      <h3>Smart Lecturer</h3>
      <textarea value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="Ask about this lesson..." />
      <button onClick={askSmartLecturer} disabled={loading || !question.trim()}>{loading ? 'Thinking...' : 'Ask'}</button>
      {answer && <pre>{answer}</pre>}
    </aside>
  );
}
