import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { IcsLiveBridgeModule } from './ics-live-bridge/ics-live-bridge.module';
import { PrismaModule } from './prisma/prisma.module';

@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true }), PrismaModule, IcsLiveBridgeModule],
})
export class AppModule {}
