import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthBridgeController } from './auth-bridge.controller';
import { LiveAccessController } from './live-access.controller';
import { AiTutorController } from './ai-tutor.controller';
import { ComplianceController } from './compliance.controller';
import { TokenService } from './token.service';
import { LiveAccessService } from './live-access.service';
import { AiTutorBridgeService } from './ai-tutor-bridge.service';
import { ComplianceService } from './compliance.service';

@Module({
  imports: [JwtModule.register({})],
  controllers: [AuthBridgeController, LiveAccessController, AiTutorController, ComplianceController],
  providers: [TokenService, LiveAccessService, AiTutorBridgeService, ComplianceService],
})
export class IcsLiveBridgeModule {}
