import { ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { TokenService } from './token.service';

@Injectable()
export class LiveAccessService {
  constructor(private readonly prisma: PrismaService, private readonly tokens: TokenService) {}

  async me(authHeader?: string) {
    if (!authHeader?.startsWith('Bearer ')) throw new UnauthorizedException('Missing bearer token');
    const payload = this.tokens.verify(authHeader.replace('Bearer ', ''));
    const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || user.status !== 'ACTIVE') throw new UnauthorizedException('Inactive or missing user');
    return { id: user.id, email: user.email, fullName: user.fullName, role: user.role, status: user.status };
  }

  async validate(accessToken: string, liveSessionId: string) {
    const payload = this.tokens.verify(accessToken);
    const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || user.status !== 'ACTIVE') throw new UnauthorizedException('Invalid user');

    const liveSession = await this.prisma.liveSession.findUnique({ where: { id: liveSessionId } });
    if (!liveSession || liveSession.status !== 'ACTIVE') throw new ForbiddenException('Live session unavailable');

    if (user.role === 'ADMIN' || user.role === 'LECTURER') {
      return { allowed: true, user, liveSession, reason: 'STAFF_ACCESS' };
    }

    const enrollment = await this.prisma.enrollment.findFirst({
      where: { studentId: user.id, courseId: liveSession.courseId, status: 'ACTIVE' },
    });
    if (!enrollment) throw new ForbiddenException('No active enrollment for this session');

    return { allowed: true, user, liveSession, enrollment, reason: 'ACTIVE_ENROLLMENT' };
  }
}
