import { Body, Controller, Post } from '@nestjs/common';
import { LiveAccessService } from './live-access.service';

@Controller('live/access')
export class LiveAccessController {
  constructor(private readonly access: LiveAccessService) {}

  @Post('validate')
  validate(@Body() body: { accessToken: string; liveSessionId: string }) {
    return this.access.validate(body.accessToken, body.liveSessionId);
  }
}
