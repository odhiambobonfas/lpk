import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class TokenService {
  constructor(private readonly config: ConfigService, private readonly jwt: JwtService) {}

  verify(token: string) {
    const secret = this.config.get<string>('JWT_ACCESS_SECRET');
    if (!secret) throw new Error('JWT_ACCESS_SECRET is required');
    try {
      return this.jwt.verify(token, { secret });
    } catch {
      throw new UnauthorizedException('Invalid access token');
    }
  }
}
