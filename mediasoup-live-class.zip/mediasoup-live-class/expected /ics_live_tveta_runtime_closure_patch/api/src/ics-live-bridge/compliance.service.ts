import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ComplianceService {
  constructor(private readonly prisma: PrismaService) {}

  capture(input: { evidenceType: string; studentId?: string; liveSessionId?: string; payload?: Record<string, unknown> }) {
    return this.prisma.complianceEvidence.create({
      data: {
        evidenceType: input.evidenceType,
        studentId: input.studentId ?? null,
        liveSessionId: input.liveSessionId ?? null,
        payload: input.payload ?? {},
      },
    });
  }
}
