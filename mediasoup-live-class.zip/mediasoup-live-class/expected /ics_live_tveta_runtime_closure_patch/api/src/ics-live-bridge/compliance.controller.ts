import { Body, Controller, Post } from '@nestjs/common';
import { ComplianceService } from './compliance.service';

@Controller('compliance')
export class ComplianceController {
  constructor(private readonly compliance: ComplianceService) {}

  @Post('evidence')
  capture(@Body() body: { evidenceType: string; studentId?: string; liveSessionId?: string; payload?: Record<string, unknown> }) {
    return this.compliance.capture(body);
  }
}
