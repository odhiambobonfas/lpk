import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AiTutorBridgeService {
  constructor(private readonly prisma: PrismaService) {}

  async ask(input: { question: string; studentId?: string; courseId?: string; liveSessionId?: string }) {
    const resources = input.courseId
      ? await this.prisma.libraryResource.findMany({ where: { courseId: input.courseId }, take: 3 })
      : [];

    const answer = [
      'Smart Lecturer response:',
      `Question: ${input.question}`,
      input.courseId ? `Course context: ${input.courseId}` : 'No course context supplied.',
      resources.length ? `Recommended resources: ${resources.map((r) => r.title).join(', ')}` : 'No linked e-library resource found yet.',
    ].join('\n');

    await this.prisma.aiTutorLog.create({
      data: {
        studentId: input.studentId ?? null,
        courseId: input.courseId ?? null,
        liveSessionId: input.liveSessionId ?? null,
        question: input.question,
        answer,
      },
    });

    return { answer, sources: resources };
  }
}
