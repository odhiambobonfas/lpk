import { Body, Controller, Post } from '@nestjs/common';
import { AiTutorBridgeService } from './ai-tutor-bridge.service';

@Controller()
export class AiTutorController {
  constructor(private readonly tutor: AiTutorBridgeService) {}

  @Post('ai-tutor/ask')
  ask(@Body() body: { question: string; studentId?: string; courseId?: string; liveSessionId?: string }) {
    return this.tutor.ask(body);
  }

  @Post('tutor/ask')
  askAlias(@Body() body: { question: string; studentId?: string; courseId?: string; liveSessionId?: string }) {
    return this.tutor.ask(body);
  }
}
