import { Controller, Get, Headers } from '@nestjs/common';
import { LiveAccessService } from './live-access.service';

@Controller('auth')
export class AuthBridgeController {
  constructor(private readonly access: LiveAccessService) {}

  @Get('me')
  me(@Headers('authorization') authorization?: string) {
    return this.access.me(authorization);
  }
}
