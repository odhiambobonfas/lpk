import { PrismaClient, UserRole, UserStatus, LiveSessionStatus } from '@prisma/client';
import { JwtService } from '@nestjs/jwt';

const prisma = new PrismaClient();

async function main() {
  const course = await prisma.course.upsert({
    where: { code: 'ELEC-101' },
    update: {},
    create: { code: 'ELEC-101', title: 'Electrical Installation Basics' },
  });

  const student = await prisma.user.upsert({
    where: { email: 'student@ics.ac.ke' },
    update: {},
    create: { email: 'student@ics.ac.ke', fullName: 'Demo Student', role: UserRole.STUDENT, status: UserStatus.ACTIVE },
  });

  const lecturer = await prisma.user.upsert({
    where: { email: 'lecturer@ics.ac.ke' },
    update: {},
    create: { email: 'lecturer@ics.ac.ke', fullName: 'Demo Lecturer', role: UserRole.LECTURER, status: UserStatus.ACTIVE },
  });

  await prisma.enrollment.upsert({
    where: { studentId_courseId: { studentId: student.id, courseId: course.id } },
    update: { status: 'ACTIVE' },
    create: { studentId: student.id, courseId: course.id, status: 'ACTIVE' },
  });

  const liveSession = await prisma.liveSession.create({
    data: { courseId: course.id, title: 'Demo ICS Live TVETA Class', status: LiveSessionStatus.ACTIVE, startsAt: new Date() },
  });

  await prisma.libraryResource.create({
    data: { courseId: course.id, title: 'Electrical Safety Notes', author: 'ICS Library', url: 'https://example.com/electrical-safety.pdf', topic: 'Electrical safety', pageFrom: 1, pageTo: 12 },
  });

  const jwt = new JwtService();
  const secret = process.env.JWT_ACCESS_SECRET || 'dev-secret-change-me';
  const studentAccessToken = await jwt.signAsync({ sub: student.id, email: student.email, role: student.role, sessionId: 'seed-student' }, { secret, expiresIn: '1h' });
  const lecturerAccessToken = await jwt.signAsync({ sub: lecturer.id, email: lecturer.email, role: lecturer.role, sessionId: 'seed-lecturer' }, { secret, expiresIn: '1h' });

  console.log('Seed complete');
  console.log({ courseId: course.id, liveSessionId: liveSession.id });
  console.log('STUDENT_ACCESS_TOKEN=', studentAccessToken);
  console.log('LECTURER_ACCESS_TOKEN=', lecturerAccessToken);
}

main().finally(async () => prisma.$disconnect());
