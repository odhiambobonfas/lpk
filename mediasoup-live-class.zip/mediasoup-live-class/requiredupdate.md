# Required Updates — ICS Live TVETA Runtime Closure Patch

## Background / Diagnostic Context

The TVETA/ODeL integration was already **wired** in the codebase but **non-functional** because the NestJS Institutional API Bridge was missing runtime scaffolding. A diagnostic report found **four failures**:

1. **API service down on port 3000** — the NestJS bridge was never created/running
2. **WsServer.ts rejects all users** because it tries to call `/api/auth/me` which unreachably fails
3. **Prisma TVETA tables were not migrated** — the database schema was never applied
4. **Smart Lecturer sidebar calls a dead endpoint** — `/api/ai-tutor/ask` doesn't exist

This patch fixes those failures by adding a runnable NestJS API bridge, active Prisma schema, seed script, and the missing endpoints.

## Overview

This document details every feature and file change needed to integrate the TVETA/ODeL runtime closure patch into the mediasoup-live-class project. The patch adds an institutional API bridge (NestJS + Prisma), token-based authentication for live sessions, an AI tutor endpoint, compliance evidence capture, mediasoup server integration, and a frontend Smart Lecturer sidebar.

---

## 1. New NestJS API Bridge (`api/`)

Create a new `api/` directory as a standalone NestJS application.

### 1.1 Configuration & Scaffolding

| File | Content |
|------|---------|
| `api/package.json` | NestJS deps: `@nestjs/common`, `@nestjs/config`, `@nestjs/core`, `@nestjs/jwt`, `@nestjs/platform-express`, `@prisma/client`, `class-transformer`, `class-validator`, `reflect-metadata`, `rxjs` |
| `api/nest-cli.json` | `{"collection":"@nestjs/schematics","sourceRoot":"src"}` |
| `api/tsconfig.json` | commonjs module, decorators enabled, ES2021 target, strict mode |
| `api/.env.example` | `DATABASE_URL`, `PORT`, `JWT_ACCESS_SECRET`, `ICS_LIVE_SERVICE_TOKEN` |

### 1.2 NestJS Entry Point (`api/src/main.ts`)

```typescript
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({ origin: true, credentials: true });
  app.setGlobalPrefix('api');
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  const port = app.get(ConfigService).get<number>('PORT') || 3000;
  await app.listen(port);
  console.log(`ICS Live TVETA API Bridge running on http://localhost:${port}/api`);
}
bootstrap();
```

### 1.3 Prisma Layer

**`api/src/prisma/prisma.module.ts`**
- `@Global()` module
- Provide and export `PrismaService`

```typescript
import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Global()
@Module({ providers: [PrismaService], exports: [PrismaService] })
export class PrismaModule {}
```

**`api/src/prisma/prisma.service.ts`**
- Extend `PrismaClient`, implement `OnModuleInit`
- Call `this.$connect()` in `onModuleInit()`

```typescript
import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() {
    await this.$connect();
  }
}
```

**`api/prisma/schema.prisma`**
- Datasource: PostgreSQL with `DATABASE_URL` env var
- Models:
  - `User` — id, email (unique), fullName, role (enum: STUDENT/LECTURER/ADMIN), status (enum: ACTIVE/SUSPENDED/PENDING), enrollments relation, createdAt
  - `Course` — id, code (unique), title, enrollments relation, liveSessions relation, resources relation
  - `Enrollment` — id, studentId + courseId (unique compound), status, relations to User and Course
  - `LiveSession` — id, courseId, title, status (enum: SCHEDULED/ACTIVE/ENDED/CANCELLED), startsAt, endsAt, relation to Course
  - `ComplianceEvidence` — id, evidenceType, studentId?, liveSessionId?, payload (Json), createdAt
  - `LibraryResource` — id, courseId?, title, author?, url, topic?, pageFrom?, pageTo?, relation to Course, createdAt
  - `AiTutorLog` — id, studentId?, courseId?, liveSessionId?, question, answer, createdAt

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

enum UserRole { STUDENT LECTURER ADMIN }
enum UserStatus { ACTIVE SUSPENDED PENDING }
enum LiveSessionStatus { SCHEDULED ACTIVE ENDED CANCELLED }

model User {
  id          String       @id @default(cuid())
  email       String       @unique
  fullName    String
  role        UserRole
  status      UserStatus   @default(ACTIVE)
  enrollments Enrollment[]
  createdAt   DateTime     @default(now())
}

model Course {
  id           String       @id @default(cuid())
  code         String       @unique
  title        String
  enrollments  Enrollment[]
  liveSessions LiveSession[]
  resources    LibraryResource[]
}

model Enrollment {
  id        String   @id @default(cuid())
  studentId String
  courseId  String
  status    String   @default("ACTIVE")
  student   User     @relation(fields: [studentId], references: [id], onDelete: Cascade)
  course    Course   @relation(fields: [courseId], references: [id], onDelete: Cascade)
  @@unique([studentId, courseId])
}

model LiveSession {
  id        String            @id @default(cuid())
  courseId  String
  title     String
  status    LiveSessionStatus @default(SCHEDULED)
  startsAt  DateTime
  endsAt    DateTime?
  course    Course            @relation(fields: [courseId], references: [id], onDelete: Cascade)
}

model ComplianceEvidence {
  id            String   @id @default(cuid())
  evidenceType  String
  studentId     String?
  liveSessionId String?
  payload       Json
  createdAt     DateTime @default(now())
}

model LibraryResource {
  id        String   @id @default(cuid())
  courseId  String?
  title     String
  author    String?
  url       String
  topic     String?
  pageFrom  Int?
  pageTo    Int?
  course    Course?  @relation(fields: [courseId], references: [id], onDelete: SetNull)
  createdAt DateTime @default(now())
}

model AiTutorLog {
  id            String   @id @default(cuid())
  studentId     String?
  courseId      String?
  liveSessionId String?
  question      String
  answer        String
  createdAt     DateTime @default(now())
}
```

**`api/prisma/seed.ts`**
- Connect to Prisma
- Upsert course `ELEC-101` (Electrical Installation Basics)
- Upsert student (`student@ics.ac.ke`) and lecturer (`lecturer@ics.ac.ke`) users
- Upsert active enrollment for student in course
- Create an active LiveSession
- Create a LibraryResource
- Generate JWT tokens for student and lecturer using `JwtService` + `JWT_ACCESS_SECRET`
- Print tokens and IDs to stdout

```typescript
import { PrismaClient, UserRole, UserStatus, LiveSessionStatus } from '@prisma/client';
import { JwtService } from '@nestjs/jwt';

const prisma = new PrismaClient();

async function main() {
  const course = await prisma.course.upsert({
    where: { code: 'ELEC-101' },
    update: {},
    create: { code: 'ELEC-101', title: 'Electrical Installation Basics' },
  });

  const student = await prisma.user.upsert({
    where: { email: 'student@ics.ac.ke' },
    update: {},
    create: { email: 'student@ics.ac.ke', fullName: 'Demo Student', role: UserRole.STUDENT, status: UserStatus.ACTIVE },
  });

  const lecturer = await prisma.user.upsert({
    where: { email: 'lecturer@ics.ac.ke' },
    update: {},
    create: { email: 'lecturer@ics.ac.ke', fullName: 'Demo Lecturer', role: UserRole.LECTURER, status: UserStatus.ACTIVE },
  });

  await prisma.enrollment.upsert({
    where: { studentId_courseId: { studentId: student.id, courseId: course.id } },
    update: { status: 'ACTIVE' },
    create: { studentId: student.id, courseId: course.id, status: 'ACTIVE' },
  });

  const liveSession = await prisma.liveSession.create({
    data: { courseId: course.id, title: 'Demo ICS Live TVETA Class', status: LiveSessionStatus.ACTIVE, startsAt: new Date() },
  });

  await prisma.libraryResource.create({
    data: { courseId: course.id, title: 'Electrical Safety Notes', author: 'ICS Library', url: 'https://example.com/electrical-safety.pdf', topic: 'Electrical safety', pageFrom: 1, pageTo: 12 },
  });

  const jwt = new JwtService();
  const secret = process.env.JWT_ACCESS_SECRET || 'dev-secret-change-me';
  const studentAccessToken = await jwt.signAsync({ sub: student.id, email: student.email, role: student.role, sessionId: 'seed-student' }, { secret, expiresIn: '1h' });
  const lecturerAccessToken = await jwt.signAsync({ sub: lecturer.id, email: lecturer.email, role: lecturer.role, sessionId: 'seed-lecturer' }, { secret, expiresIn: '1h' });

  console.log('Seed complete');
  console.log({ courseId: course.id, liveSessionId: liveSession.id });
  console.log('STUDENT_ACCESS_TOKEN=', studentAccessToken);
  console.log('LECTURER_ACCESS_TOKEN=', lecturerAccessToken);
}

main().finally(async () => prisma.$disconnect());
```

### 1.4 Live Access Service (`api/src/ics-live-bridge/live-access.service.ts`)

```typescript
import { ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { TokenService } from './token.service';

@Injectable()
export class LiveAccessService {
  constructor(private readonly prisma: PrismaService, private readonly tokens: TokenService) {}

  async me(authHeader?: string) {
    if (!authHeader?.startsWith('Bearer ')) throw new UnauthorizedException('Missing bearer token');
    const payload = this.tokens.verify(authHeader.replace('Bearer ', ''));
    const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || user.status !== 'ACTIVE') throw new UnauthorizedException('Inactive or missing user');
    return { id: user.id, email: user.email, fullName: user.fullName, role: user.role, status: user.status };
  }

  async validate(accessToken: string, liveSessionId: string) {
    const payload = this.tokens.verify(accessToken);
    const user = await this.prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || user.status !== 'ACTIVE') throw new UnauthorizedException('Invalid user');

    const liveSession = await this.prisma.liveSession.findUnique({ where: { id: liveSessionId } });
    if (!liveSession || liveSession.status !== 'ACTIVE') throw new ForbiddenException('Live session unavailable');

    if (user.role === 'ADMIN' || user.role === 'LECTURER') {
      return { allowed: true, user, liveSession, reason: 'STAFF_ACCESS' };
    }

    const enrollment = await this.prisma.enrollment.findFirst({
      where: { studentId: user.id, courseId: liveSession.courseId, status: 'ACTIVE' },
    });
    if (!enrollment) throw new ForbiddenException('No active enrollment for this session');

    return { allowed: true, user, liveSession, enrollment, reason: 'ACTIVE_ENROLLMENT' };
  }
}
```

### 1.5 AI Tutor Service (`api/src/ics-live-bridge/ai-tutor-bridge.service.ts`)

```typescript
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AiTutorBridgeService {
  constructor(private readonly prisma: PrismaService) {}

  async ask(input: { question: string; studentId?: string; courseId?: string; liveSessionId?: string }) {
    const resources = input.courseId
      ? await this.prisma.libraryResource.findMany({ where: { courseId: input.courseId }, take: 3 })
      : [];

    const answer = [
      'Smart Lecturer response:',
      `Question: ${input.question}`,
      input.courseId ? `Course context: ${input.courseId}` : 'No course context supplied.',
      resources.length ? `Recommended resources: ${resources.map((r) => r.title).join(', ')}` : 'No linked e-library resource found yet.',
    ].join('\n');

    await this.prisma.aiTutorLog.create({
      data: {
        studentId: input.studentId ?? null,
        courseId: input.courseId ?? null,
        liveSessionId: input.liveSessionId ?? null,
        question: input.question,
        answer,
      },
    });

    return { answer, sources: resources };
  }
}
```

---

## 2. Mediasoup Server Integration (`server/`)

### 2.1 Environment Variables

**Add to `server/.env`:**
```env
ICS_LIVE_API_BASE_URL=http://localhost:3000/api
ICS_LIVE_SERVICE_TOKEN=replace-with-shared-service-token
```

### 2.2 Auth Bridge Patch (`server/src/IcsLiveAuthBridge.ts`)

```typescript
export async function validateIcsLiveToken(accessToken: string) {
  const baseUrl = process.env.ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';
  const res = await fetch(`${baseUrl}/auth/me`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) throw new Error(`ICS_LIVE_AUTH_FAILED:${res.status}`);
  return res.json();
}

export async function validateLiveAccess(accessToken: string, liveSessionId: string) {
  const baseUrl = process.env.ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';
  const res = await fetch(`${baseUrl}/live/access/validate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.ICS_LIVE_SERVICE_TOKEN || ''}`
    },
    body: JSON.stringify({ accessToken, liveSessionId }),
  });
  if (!res.ok) throw new Error(`ICS_LIVE_ACCESS_DENIED:${res.status}`);
  return res.json();
}
```

### 2.3 `WsServer.ts` Integration

In `server/src/WsServer.ts`, integrate token validation within the `connectionrequest` listener:

```typescript
// Example integration logic (to be inserted in handleProtooServer)
const accessToken = params.get('accessToken');
if (accessToken) {
    try {
        const userInfo = await validateIcsLiveToken(accessToken);
        logger.info('ICS Live User Authenticated: %o', userInfo);
        // Additional logic for liveSessionId validation can go here
    } catch (error) {
        reject(401, 'Unauthorized: ICS Live token validation failed');
        return;
    }
}
```

---

## 3. Frontend Integration (`app/`)

### 3.1 Smart Lecturer Sidebar (`app/src/components/SmartLecturerSidebar.jsx`)

```jsx
import React, { useState } from 'react';

const API_BASE_URL = import.meta.env.VITE_ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';

export function SmartLecturerSidebar({ accessToken, studentId, courseId, liveSessionId }) {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  async function askSmartLecturer() {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/ai-tutor/ask`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`
        },
        body: JSON.stringify({ question, studentId, courseId, liveSessionId }),
      });
      if (!res.ok) throw new Error(`Smart Lecturer failed: ${res.status}`);
      const data = await res.json();
      setAnswer(data.answer);
    } catch (err) {
      setAnswer(err.message || 'Smart Lecturer connection failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <aside className="smart-lecturer-sidebar">
      <h3>Smart Lecturer</h3>
      <textarea
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Ask about this lesson..."
      />
      <button onClick={askSmartLecturer} disabled={loading || !question.trim()}>
        {loading ? 'Thinking...' : 'Ask'}
      </button>
      {answer && <pre>{answer}</pre>}
    </aside>
  );
}
```

---

## 4. Run-to-Green Manual

1. **Configure API Bridge:** `cd api && cp .env.example .env` (Set `DATABASE_URL`).
2. **Install & Migrate:** `npm install`, `npx prisma generate`, `npx prisma migrate dev`, `npm run seed`.
3. **Start API:** `npm run start:dev`.
4. **Verify:** Use `curl` to test `/api/auth/me` with the generated `STUDENT_ACCESS_TOKEN`.
5. **Align Servers:** Ensure `server/.env` and `app/.env` point to the NestJS API.
6. **Launch Full Stack:** Start mediasoup server and React frontend.
