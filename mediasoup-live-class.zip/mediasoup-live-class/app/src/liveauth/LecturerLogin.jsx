import React, { useState } from 'react';
import { createMeeting } from './institutionalApi';

export default function LecturerLogin({ onBack, onJoin }) {
	const [lecturerId, setLecturerId] = useState('');
	const [courseTitle, setCourseTitle] = useState('');
	const [courseCode, setCourseCode] = useState('');
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState('');

	const handleCreate = async (e) => {
		e.preventDefault();
		if (!lecturerId || !courseTitle || !courseCode) return;

		setLoading(true);
		setError('');
		try {
			const { roomId, accessToken, lecturerName } = await createMeeting({
				lecturerId,
				courseTitle,
				courseCode
			});
			onJoin(roomId, lecturerName, 'create', accessToken);
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	};

	return (
		<div className="lp-card lp-card--create" style={{ maxWidth: '500px', margin: '0 auto' }}>
			<div className="lp-card-header">
				<div className="lp-card-icon" onClick={onBack} style={{ cursor: 'pointer' }}>
					<i className="bi bi-chevron-left" />
				</div>
				<div>
					<h3 className="lp-card-title">Lecturer Session</h3>
				</div>
			</div>

			<form onSubmit={handleCreate} className="lp-form">
				<div className="lp-identity">
					<label className="lp-identity-label">Institutional ID</label>
					<input
						type="text"
						className="lp-identity-input"
						placeholder="Lecturer ID Number"
						value={lecturerId}
						onChange={(e) => setLecturerId(e.target.value)}
						required
					/>
				</div>

				<div className="lp-identity" style={{ marginTop: '15px' }}>
					<label className="lp-identity-label">Course Title</label>
					<input
						type="text"
						className="lp-identity-input"
						placeholder="e.g. Introduction to Robotics"
						value={courseTitle}
						onChange={(e) => setCourseTitle(e.target.value)}
						required
					/>
				</div>

				<div className="lp-identity" style={{ marginTop: '15px' }}>
					<label className="lp-identity-label">Course Code</label>
					<input
						type="text"
						className="lp-identity-input"
						placeholder="e.g. ROB-101"
						value={courseCode}
						onChange={(e) => setCourseCode(e.target.value)}
						required
					/>
				</div>

				{error && <div className="lp-error-msg">{error}</div>}

				<div className="lp-card-divider-create" />

				<button
					type="submit"
					className="lp-btn lp-btn--create"
					disabled={loading || !lecturerId || !courseTitle || !courseCode}
				>
					{loading ? 'Creating Session...' : 'Launch Meeting'}
					{!loading && <span className="lp-btn-arrow">→</span>}
				</button>
			</form>
		</div>
	);
}
