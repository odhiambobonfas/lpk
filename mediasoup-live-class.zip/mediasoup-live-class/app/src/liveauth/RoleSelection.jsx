import React from 'react';

export default function RoleSelection({ onSelect }) {
	return (
		<div className="lp-cards">
			<div className="lp-card lp-card--join" onClick={() => onSelect('student')}>
				<div className="lp-card-header">
					<div className="lp-card-icon">
						<i className="bi bi-person-video" />
					</div>
					<div>
						<h3 className="lp-card-title">I am a Student</h3>
					</div>
				</div>
				<p className="lp-card-desc">
					Join an ongoing lecture using your Student ID and Meeting ID.
				</p>
				<button className="lp-btn lp-btn--join" style={{ marginTop: 'auto' }}>
					Join Class <span className="lp-btn-arrow">→</span>
				</button>
			</div>

			<div className="lp-card lp-card--create" onClick={() => onSelect('lecturer')}>
				<div className="lp-card-header">
					<div className="lp-card-icon">
						<i className="bi bi-person-badge" />
					</div>
					<div>
						<h3 className="lp-card-title">I am a Lecturer</h3>
					</div>
				</div>
				<p className="lp-card-desc">
					Start a new live session and manage your classroom.
				</p>
				<button className="lp-btn lp-btn--create" style={{ marginTop: 'auto' }}>
					Launch Meeting <span className="lp-btn-arrow">→</span>
				</button>
			</div>
		</div>
	);
}
