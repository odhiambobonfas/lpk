const API_BASE_URL = import.meta.env.VITE_ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';
const USE_MOCK = true; // Set to true for immediate testing without backend

export async function createMeeting({ lecturerId, courseTitle, courseCode }) {
	if (USE_MOCK) {
		console.log('Using Mock API for createMeeting');
		return {
			roomId: Math.random().toString(36).substring(2, 10),
			accessToken: 'mock-lecturer-token',
			lecturerName: `Lecturer (${lecturerId})`
		};
	}

	const response = await fetch(`${API_BASE_URL}/live-sessions/create`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({ lecturerId, courseTitle, courseCode }),
	});

	if (!response.ok) {
		const error = await response.json();
		throw new Error(error.message || 'Failed to create meeting');
	}

	return response.json(); // { roomId, accessToken, lecturerName }
}

export async function validateStudent({ studentId, meetingId }) {
	if (USE_MOCK) {
		console.log('Using Mock API for validateStudent');
		return {
			accessToken: 'mock-student-token',
			studentName: `Student (${studentId})`
		};
	}

	const response = await fetch(`${API_BASE_URL}/live/access/validate-student`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({ studentId, meetingId }),
	});

	if (!response.ok) {
		const error = await response.json();
		throw new Error(error.message || 'Access denied');
	}

	return response.json(); // { accessToken, studentName }
}
