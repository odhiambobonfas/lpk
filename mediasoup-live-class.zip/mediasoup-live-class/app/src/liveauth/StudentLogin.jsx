import React, { useState } from 'react';
import { validateStudent } from './institutionalApi';

export default function StudentLogin({ onBack, onJoin }) {
	const [studentId, setStudentId] = useState('');
	const [meetingId, setMeetingId] = useState('');
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState('');

	const handleJoin = async (e) => {
		e.preventDefault();
		if (!studentId || !meetingId) return;

		setLoading(true);
		setError('');
		try {
			const { accessToken, studentName } = await validateStudent({ studentId, meetingId });
			onJoin(meetingId, studentName, 'join', accessToken);
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	};

	return (
		<div className="lp-card lp-card--join" style={{ maxWidth: '450px', margin: '0 auto' }}>
			<div className="lp-card-header">
				<div className="lp-card-icon" onClick={onBack} style={{ cursor: 'pointer' }}>
					<i className="bi bi-chevron-left" />
				</div>
				<div>
					<h3 className="lp-card-title">Student Login</h3>
				</div>
			</div>

			<form onSubmit={handleJoin} className="lp-form">
				<div className="lp-identity">
					<label className="lp-identity-label">Student ID Number</label>
					<input
						type="text"
						className="lp-identity-input"
						placeholder="e.g. 2024-001"
						value={studentId}
						onChange={(e) => setStudentId(e.target.value)}
						required
					/>
				</div>

				<div className="lp-identity" style={{ marginTop: '20px' }}>
					<label className="lp-identity-label">Meeting ID</label>
					<input
						type="text"
						className="lp-identity-input"
						placeholder="CLASS-ID-000"
						value={meetingId}
						onChange={(e) => setMeetingId(e.target.value)}
						required
					/>
				</div>

				{error && <div className="lp-error-msg">{error}</div>}

				<div className="lp-card-divider-join" />

				<button
					type="submit"
					className="lp-btn lp-btn--join"
					disabled={loading || !studentId || !meetingId}
				>
					{loading ? 'Verifying...' : 'Join Classroom'}
					{!loading && <span className="lp-btn-arrow">→</span>}
				</button>
			</form>
		</div>
	);
}
