import React, { useState, useEffect } from 'react';
import { cn } from '../utils';
import '../scss/landing-page.css';
import * as cookiesManager from '../cookiesManager';
import RoleSelection from '../liveauth/RoleSelection';
import StudentLogin from '../liveauth/StudentLogin';
import LecturerLogin from '../liveauth/LecturerLogin';

const features = [
	'Live HD Video Stream',
	'Verified Educator Session',
	'Interactive Student Grid',
	'Screen Sharing & Chat',
];

const footerChips = [
	{ dot: 'emerald', label: 'Lecture Grid' },
	{ dot: 'gold', label: 'Ultra-Low Latency' },
	{ dot: 'white', label: 'End-to-End Encrypted' },
	{ dot: 'emerald', label: 'Screen Sharing' },
];

export default function LandingPage({ onJoin, initialRoomId }) {
	const [view, setView] = useState(initialRoomId ? 'student' : 'selection');
	const [initialRoomIdState] = useState(initialRoomId || '');

	return (
		<div className="lp-root">
			<div className="lp-animated-bg">
				<div className="lp-blob lp-blob-1" />
				<div className="lp-blob lp-blob-2" />
				<div className="lp-blob lp-blob-3" />
				<div className="lp-grid-overlay" />
			</div>

			<nav className="lp-nav">
				<a className="lp-nav-brand" href="#">
					<img src="/images/logo.png" alt="ICS" className="lp-nav-logo" />
					<span className="lp-nav-name">
						ICS <span>LIVE</span>
					</span>
				</a>

				<div className="lp-nav-links">
					<a href="#">Platform</a>
					<a href="#">Resources</a>
					<a href="#">Support</a>
				</div>

				<div className="lp-nav-badge">
					<div className="lp-nav-badge-dot" />
					<span>Secure Session</span>
				</div>
			</nav>

			<main className="lp-main">
				<div className="lp-hero">
					<div className="lp-hero-eyebrow">Virtual Classroom Platform</div>
					<h1 className="lp-hero-title">ICS LIVE</h1>
					<p className="lp-hero-subtitle">
						Advanced virtual classroom for excellence in education — built for
						educators and students.
					</p>
				</div>

				{view === 'selection' && (
					<RoleSelection onSelect={(role) => setView(role)} />
				)}

				{view === 'student' && (
					<StudentLogin
						onBack={() => setView('selection')}
						onJoin={onJoin}
						initialRoomId={initialRoomIdState}
					/>
				)}

				{view === 'lecturer' && (
					<LecturerLogin
						onBack={() => setView('selection')}
						onJoin={onJoin}
					/>
				)}

				<div className="lp-footer">
					{footerChips.map(({ dot, label }, i) => (
						<div className="lp-chip" key={i}>
							<div className={cn('lp-chip-dot', `lp-chip-dot--${dot}`)} />
							{label}
						</div>
					))}
				</div>
			</main>
		</div>
	);
}
