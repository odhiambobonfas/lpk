import qs from 'qs';

const urlParser = new URL(window.location.href);
const urlParams = qs.parse(urlParser.search, { ignoreQueryPrefix: true });

const hostname = urlParams.infoHost || window.location.hostname;
const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';

export function getProtooUrl({ roomId, peerId, accessToken, consumerReplicas, usePipeTransports }) {
	const query = qs.stringify({
		roomId,
		peerId,
		accessToken,
		consumerReplicas,
		usePipeTransports,
	});

	if (urlParams.infoPort) {
		return `${protocol}://${hostname}:${urlParams.infoPort}/?${query}`;
	}

	// If we are on ngrok and no specific port was provided, 
	// use the default HTTPS/HTTP port (443/80) because ngrok handles the mapping.
	const isNgrok = hostname.endsWith('.ngrok.io') || hostname.endsWith('.ngrok-free.app');

	if (isNgrok) {
		return `${protocol}://${hostname}/?${query}`;
	}

	if (hostname === 'localhost') {
		return `${protocol}://${hostname}:4443/?${query}`;
	}

	// Use same origin (no explicit port, /ws path) so WS goes through nginx proxy
	return `${protocol}://${hostname}/ws?${query}`;
}
