const initialState = {
	url: null,
	state: 'new', // new/connecting/connected/disconnected/closed,
	mediasoupVersion: undefined,
	mediasoupClientVersion: undefined,
	mediasoupClientHandler: undefined,
	activeSpeakerId: undefined,
	speakingPeerIds: [],
	statsPeerId: undefined,
	faceDetection: false,
};

const room = (state = initialState, action) => {
	switch (action.type) {
		case 'SET_ROOM_URL': {
			const { url } = action.payload;

			return { ...state, url };
		}

		case 'SET_ROOM_STATE': {
			const roomState = action.payload.state;

			if (roomState === 'connected') return { ...state, state: roomState };
			else
				return {
					...state,
					state: roomState,
					activeSpeakerId: undefined,
					speakingPeerIds: [],
					statsPeerId: undefined,
				};
		}

		case 'SET_ROOM_MEDIASOUP_CLIENT_HANDLER': {
			const { mediasoupClientHandler } = action.payload;

			return { ...state, mediasoupClientHandler };
		}

		case 'SET_MEDIASOUP_VERSION': {
			const { version } = action.payload;

			return { ...state, mediasoupVersion: version };
		}

		case 'SET_MEDIASOUP_CLIENT_VERSION': {
			const { version } = action.payload;

			return { ...state, mediasoupClientVersion: version };
		}

		case 'SET_ROOM_ACTIVE_SPEAKER': {
			const { peerId } = action.payload;

			return { ...state, activeSpeakerId: peerId };
		}

		case 'SET_ROOM_SPEAKING_PEERS': {
			const { peerIds } = action.payload;

			return { ...state, speakingPeerIds: peerIds };
		}

		case 'SET_ROOM_STATS_PEER_ID': {
			const { peerId } = action.payload;

			if (state.statsPeerId === peerId)
				return { ...state, statsPeerId: undefined };

			return { ...state, statsPeerId: peerId };
		}

		case 'SET_FACE_DETECTION': {
			const flag = action.payload;

			return { ...state, faceDetection: flag };
		}

		case 'REMOVE_PEER': {
			const { peerId } = action.payload;
			const newState = { ...state };

			if (peerId && peerId === state.activeSpeakerId)
				newState.activeSpeakerId = undefined;

			newState.speakingPeerIds = newState.speakingPeerIds.filter(
				otherPeerId => otherPeerId !== peerId
			);

			if (peerId && peerId === state.statsPeerId)
				newState.statsPeerId = undefined;

			return newState;
		}

		default: {
			return state;
		}
	}
};

export default room;
