import { Logger } from '../Logger';

const logger = new Logger('IcsLiveAuthBridge');

export async function validateIcsLiveToken(accessToken: string): Promise<any> {
	const baseUrl = process.env.ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';

	logger.debug('validateIcsLiveToken() [accessToken:%s]', accessToken);

	// Mock bypass for testing
	if (accessToken.startsWith('mock-')) {
		logger.warn('validateIcsLiveToken() | Using Mock Token bypass');
		return {
			sub: 'mock-user-id',
			email: 'mock@example.com',
			role: accessToken.includes('lecturer') ? 'LECTURER' : 'STUDENT'
		};
	}

	try {
		const res = await fetch(`${baseUrl}/auth/me`, {
			headers: { Authorization: `Bearer ${accessToken}` },
		});

		if (!res.ok) {
			throw new Error(`ICS_LIVE_AUTH_FAILED:${res.status}`);
		}

		return await res.json();
	} catch (error) {
		logger.error('validateIcsLiveToken() failed:%o', error);
		throw error;
	}
}

export async function validateLiveAccess(accessToken: string, liveSessionId: string): Promise<any> {
	const baseUrl = process.env.ICS_LIVE_API_BASE_URL || 'http://localhost:3000/api';

	logger.debug('validateLiveAccess() [liveSessionId:%s]', liveSessionId);

	try {
		const res = await fetch(`${baseUrl}/live/access/validate`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				Authorization: `Bearer ${process.env.ICS_LIVE_SERVICE_TOKEN || ''}`,
			},
			body: JSON.stringify({ accessToken, liveSessionId }),
		});

		if (!res.ok) {
			throw new Error(`ICS_LIVE_ACCESS_DENIED:${res.status}`);
		}

		return await res.json();
	} catch (error) {
		logger.error('validateLiveAccess() failed:%o', error);
		throw error;
	}
}
